# lcd_lib

python library for char lcd screen on raspberry pi
go to https://www.hackster.io/trduunze/raspberry-pi-lcd-screen-339eb5 for more information.
